int f(void) {
    return 1;
}
int main(void) {
    return f();
}