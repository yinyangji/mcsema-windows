int a = 0;
int main(void) {
    return (long long) &a;
}